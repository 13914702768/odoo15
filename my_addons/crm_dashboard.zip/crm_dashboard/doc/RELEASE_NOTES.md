## Module <crm_dashboard>

#### 30.10.2021
#### Version 15.0.1.0.0
#### ADD
- Initial commit for CRM Dashboard Module

#### 26.07.2022
#### Version 15.0.1.0.3
#### FIX
- Bug fixes for CRM Dashboard Module