# -*- coding: utf-8 -*-

from . import crm_lead_to_opportunity_inherit_xks