# -*- coding: utf-8 -*-

from . import crm_lead_inherit_xks
from . import res_partner_inherit_xks
from . import sales_order_inherit_xks
from . import leads_order_line_xks
from . import leads_compertitor_xks
from . import sales_order_line_inherit_xks
from . import purchase_inherit_xks
from . import product_template_inherit_xks
from . import product_product_inherit_xks
from . import product_inspection_xks
from . import product_produce_xks
from . import purchase_order_pay_xks
from . import purchase_order_line_pay_xks
from . import ir_mail_server_inherit_xks
from . import leads_plan_xks
from . import product_template_parameter_xks
from . import crm_team_member_inherit_xks